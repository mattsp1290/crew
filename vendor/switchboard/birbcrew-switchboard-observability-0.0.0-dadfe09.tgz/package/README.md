# Crew Switchboard observability extraction

Byte-identical upstream dist/observability from Switchboard dadfe09fb2f0090b46168309309ca01bb89b9a0e.
Only the observability entry and its type-only core contract are packaged.
The original instrumentation scope is retained. Crew qualifies this entry on Node 22.23.3.
Rebuild from a clean upstream checkout with Node 24 using scripts/vendor-switchboard-observability.mjs <source-path>.
See provenance.json for source and extracted SHA-256 hashes. MIT licensed.
