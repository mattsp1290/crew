# Switchboard boundaries

Switchboard supplies reusable interfaces and native adapters for a Node host.
The foundation supplies public adapter contracts, session envelope validation, bounded event streams, and package verification.
Native adapters ship for the SDK text lanes. The Codex host adapter is the `./host/codex` entry and is built on the private app-server components below. It does not replace the `./codex` text adapter.
The private core package has no mandatory runtime dependencies.
The optional `./agui` integration requires the exact peer `@ag-ui/core@1.0.4`.
The optional `./testkit` entry supplies controlled qualification scenarios without an AG-UI peer.

## GenAI observations

`src/observability/index.ts` supplies the optional `./observability` entry with the exact optional peer `@opentelemetry/api@1.9.0`.
The root and testkit entries do not load OpenTelemetry or the observability entry.
The library borrows a tracer and explicit parent contexts. The host owns provider configuration, sampling, exporters, credentials, deadlines, and shutdown.

Agent, model-request, and tool descriptors represent independently observed boundaries. Agent or dispatch phases do not establish a model request.
A text chunk is not a model call. Aggregated run usage does not establish per-request usage.
An unavailable native boundary remains unobserved. This entry does not qualify any native adapter.

Each observer owns a bounded set of live recording handles. Handles contain safe span contexts; the mutable SDK span remains private.
Success leaves OpenTelemetry status UNSET. Confirmed errors set ERROR with a fixed category.
Cancellation and uncertainty carry explicit outcomes without asserting a provider error or native cancellation.
Closing the observer ends open spans as uncertain and cannot dispatch, retry, or cancel work.
Telemetry exceptions produce fixed diagnostics and do not escape into native execution.

The GenAI profile is pinned to semantic conventions v1.37.0. No arbitrary attribute bag, native handle, exception, or tool payload is accepted.
Default policy does not traverse message content. Explicit sanitized text passes bounded exact parsing before and after the host sanitizer.
The host chooses safe public identifiers and sanitizer rules. Library validation establishes the allowed data paths, rather than proving arbitrary strings are non-secret.
Datadog metadata adaptation belongs in the host exporter. A distinct export view preserves outcome and safe correlation without changing lotel spans.

The `./baseline` entry is the adapter-facing caller of this observer and of the AG-UI projector. It records a model span only for a `model-boundary` observation; a missing model boundary stays unobserved.

[Usage](../observability/usage.md) and [destination verification](../observability/validation.md) describe host setup and deterministic qualification.

## Host ownership

Crew, AgentUI, or another consumer owns authorization policy, credential resolution, and durable command intent and outcomes.
The host also owns database storage, event replay, recovery scheduling, workflow retries, remote server lifecycle, and UI.
Native runtimes may maintain their own session files. Those files do not make Switchboard a durable workflow engine.

A local request ID does not establish exactly-once execution.
Future adapters must expose uncertainty after ambiguous native acceptance so the host can reconcile from supported native evidence.
The host must not blindly resubmit a message, approval, or continuation after losing its acknowledgement.
Cancellation does not imply rollback. Removing an observer does not imply cancellation.

Direct native authentication and proxy authentication are separate configuration paths.
LiteLLM owns upstream provider credentials. Switchboard authenticates to the proxy with host-resolved credentials.
Subscription credential passthrough through LiteLLM is outside v1.
A selected proxy route must not silently fall back to direct access.
Future adapters must scope credentials per adapter and session, preserve native approvals, and prevent secret disclosure in observable output.

## Source ownership and exports

`src/index.ts` exports core contracts and helpers without importing AG-UI.
`src/agui/index.ts` supplies the explicit `./agui` entry with pinned protocol metadata.
`src/testkit/index.ts` supplies the optional `./testkit` entry with controlled qualification groups and a reference fake.
The root entry never loads the testkit. These checks do not qualify native engines, credentials, or durable host admission.
`createAguiProjection` maps observed lifecycle, text, tool, content, step and reasoning facts through one bounded per-run actor.
Its frozen `aguiProtocol` descriptor identifies basic, value, message snapshot, terminal payload, reasoning and subagent lifecycle support with no planned output categories.
The exact 98-definition disposition audit requires actual installed output for every implemented event and all five child terminal variants.
Three chunk spellings normalize to explicit events. Input and capability declarations remain declaration values.
The root export maps to emitted JavaScript and declarations under `dist`.
Deep imports are private. The package verification command checks this restriction in an installed tarball.

The following directories describe source ownership. Core contracts live in `src/core/`; protocol mapping and metadata live in `src/agui/`.
The host-facing adapter contract is [host-adapter-contract.md](host-adapter-contract.md), typed in `src/core/host-adapter.ts`.

| Source area | Responsibility | Allowed direction |
| --- | --- | --- |
| `src/core/` | Public runtime contracts, the host-facing adapter contract, native session references, and bounded event delivery | No native SDK, adapter, or AG-UI dependency |
| `adapters/claude/src/` | Claude text adapter (`./claude` entry) | May import Claude SDK peers and `node:` builtins. Must not be imported by `src/`. Public declarations must stay SDK-free. Compiled separately by `adapters/claude/tsconfig.json` |
| `adapters/codex/src/` | Codex text adapter (`./codex` entry) | May import the Codex SDK peer and `node:` builtins. Must not be imported by `src/`. Public declarations must stay SDK-free. Compiled separately by `adapters/codex/tsconfig.json` |
| `src/adapters/codex/` | Private Codex app-server stack, not exported. The Codex host adapter will add `index.ts` here | May import core and `node:` builtins. Never imported by core or the root entry |
| `src/adapters/opencode/` | OpenCode host adapter (`./host/opencode`) | May import `src/core/` and `node:` builtins. Core and the root entry do not import it |
| `adapters/pi/src/` | Pi native integration (`./pi` entry) | May import Pi SDK peers and `node:` builtins. Must not be imported by `src/`. Public declarations must stay SDK-free. Compiled separately by `adapters/pi/tsconfig.json` |
| `adapters/cursor/src/` | Cursor text adapter (`./cursor` entry) | May import the Cursor SDK peer and `node:` builtins. Must not be imported by `src/`. Public declarations must stay SDK-free. Compiled separately by `adapters/cursor/tsconfig.json` |
| `src/agui/` | Canonical AG-UI mapping | May import core and canonical AG-UI types |
| `src/baseline/` | `./baseline` entry: maps `RunObservation` into AG-UI facts and GenAI spans. Loads both optional peers | May import core, `src/agui/`, and `src/observability/`. Never imported by core, the root entry, the testkit, or an adapter |
| `src/testkit/` | Controlled qualification scenarios, the reference fake, and the host-adapter conformance suite | May import `src/index.ts` through the relative public barrel and `node:` builtins except `node:test`. No AG-UI imports. Never imported by core. |

AgentUI keeps its separately qualified production core while adopting a newer testkit as a development dependency under an npm alias.
The aliased testkit must use its own artifact's public core at runtime and in declarations, even when an older canonical core is installed.
Production pruning must remove the development alias while retaining the qualified core.
The package gate checks the standalone alias; AgentUI's consumer qualification checks coexistence and pruning against its pinned production artifact.
Relative public-barrel imports keep this identity within the aliased artifact.

Adapters may import any value or type export of `src/core/run-observation.ts` (such as `emitRunStarted`, `jsonString`, `segmentTerminal`, and `RunObservationListener`) from `#switchboard` (separate adapter projects) or from a relative `src/core/run-observation.js` path (`src/adapters/`). They never import `src/agui`, `src/observability`, `src/baseline`, `@ag-ui/core`, or `@opentelemetry/api`.

Native adapters need their own explicit entry points when implemented.
AG-UI imports only the SDK main entry. Optional Zod and SDK schemas are not integration runtime dependencies.
Third-party adapters must use public contracts without importing internal source files.
Native dependency and package-splitting decisions belong to the adapter tasks.

## Adapter contracts

`AdapterIdentity<Engine>` identifies an engine, adapter package, adapter version, and contract generation.
Engine names form an open string domain. A concrete engine literal connects a registration to its returned instance.
`AdapterRegistration<Options, Instance>` preserves the adapter's configuration and concrete instance type through `open`.
Registration and instance identity metadata must agree. Types do not prove object-reference equality or runtime identity.
`contractVersion: 1` describes this contract generation. Identity metadata does not validate persisted native data.

`AdapterInstance` requires identity and `close`. Concrete instances define their own named capability groups.
No native capability is mandatory. Domain contracts describe optional operations. Native dispatch remains future work.
`Capability<Api>` keeps a typed API in its `supported` branch.
`unsupported` means the adapter or native version does not implement the feature.
`unavailable` means this configured instance cannot offer the feature, such as when the host disables it.
Both branches carry a reason and omit the API. Callers narrow `kind` before accessing operations.
TypeScript rejects excess API fields on fresh unsupported literals. Structural typing does not enforce exact objects after aliasing.
Capabilities describe configured availability. Operation results still handle changed native conditions and busy resources.
Capability support does not grant authorization or prove native qualification.

`Outcome<T, E = AdapterError>` distinguishes `ok` with a value from `error` with a typed error.
`AdapterError` describes unsupported requests, busy or closed instances, invalid input, and native failures.
An unsupported error names its feature. Public messages must exclude credentials and raw native responses.
Domain contracts can supply their own error type. Ordinary errors confer no permission to retry native effects.
Side-effecting domain contracts must model uncertain outcomes with operation identity and reconciliation evidence.

`NativeExtension<T = unknown>` labels adapter-specific data with a namespace and schema version.
The adapter owns those labels and the payload type. Consumers without that type receive `unknown`.
An extension promises neither serialization nor compatibility validation. Core does not log its payload.

The adapter owns clients, listeners, transports, and processes that it creates.
Adapters that accept borrowed native clients must state ownership in their options.
A failed `open` releases resources acquired before returning its error.
`close` is idempotent cleanup. Repeated and concurrent callers share one cleanup attempt and its settled outcome.
The adapter rejects new operations once closing starts and releases its owned resources.
A cleanup failure returns a redacted error and does not establish that every resource terminated.
Closing does not confirm native cancellation, roll back tool effects, delete session history, or establish safe retry.
The later domain contracts own active-work cancellation and reconciliation.

Future adapters that start a native process, directly or through a native SDK, must accept a host-supplied executable path or spawn function.
When the host supplies either, the adapter starts the native process only through it. A host launcher or remote transport can then wrap that process.
When the host supplies the environment, the adapter copies nothing from its own environment.
When the host supplies native configuration, the adapter passes it through and adds none from ambient locations.
When the host supplies the environment or native configuration, any credential the adapter adds comes only from scoped authentication.
Such adapters must state in their options whether the adapter or the host owns the native process, as for borrowed clients.
That statement names who stops the native process and its descendants on `close`, and on any cancellation that stops it.
Future adapters must work when the host confines the native process, or the process that loads a native SDK, to granted network endpoints and filesystem paths.
When host configuration shows that confinement prevents a feature, the adapter reports it as `unavailable` with a reason.
A denial first seen during an operation is an operation error.
The adapter must not fall back to an unconfined launch, or to network or filesystem access the host did not grant.
An input the host omits keeps the adapter's documented default.
The host-facing contract names the launcher, environment, native configuration, and process-ownership options. An option the host omits still keeps native behaviour.
These are requirements on adapters that implement that contract.

The installed consumer checks prove public typing and package boundaries.
They do not verify cleanup idempotence, resource release, native identity validation, or native integration behavior.
Concrete adapters require runtime tests for those promises.

## Native sessions and checkpoints

`SessionReference` and `CheckpointReference` carry Switchboard envelope `formatVersion: 1`.
Their binding identifies the engine, native version, account, adapter-specific authorized scope, and native format.
Exact native version and format equality is the conservative initial rule. Adapter package semver is not part of this binding.
Later native qualification may justify a broader compatibility rule.
Checkpoints also bind the exact session's opaque token. `SessionCorrelation` carries separate host thread, run, and request IDs.
The host owns the correlation map, persistence, and authorization. An identifier does not grant access.

The parsers accept `unknown`, check bounded nonblank strings without control characters, and reject unknown envelope versions without migration.
They copy known fields into frozen envelopes and frozen bindings. Extra input fields are discarded.
`sessionLimits` exposes the string and work ceilings. Identifiers have at most 1024 UTF-16 code units and opaque tokens at most 8192.
Core does not interpret opaque token syntax, prove authenticity, inspect private native formats, or check native existence.
Adapters validate native references before use. No parser imports, rewrites, or migrates history.

`SessionDiscovery<Scope>` and `SessionInspection<Scope>` require an explicit host-authorized adapter-specific scope, binding, bounds, and `AbortSignal`.
Adapters define scope handles and authorize discovery sources. The optional filesystem helper below requires an explicit root.
`validateSessionDiscoveryBounds` requires positive safe integers, at most 1000 returned results, 100000 examined entries, and 60000 milliseconds.
The result limit cannot exceed the examined-entry limit. Validation returns a frozen budget copy.
Adapters enforce all budgets and stop cooperatively on abort. They count each examined candidate, including filtered, corrupt, or inaccessible entries.
They remain within authorized resolved roots and symlink boundaries and read only supported native discovery sources.
Discovery reports skipped corrupt and inaccessible counts only for independently established classifications.
Pages distinguish complete, truncated by a named budget, cancelled, and failed results. A complete empty page differs from an interrupted empty page.
Every page requires `diagnostics`, with `[]` when none was observed. All diagnostic and termination combinations are valid.
`complete` means the adapter exhausted its authorized enumeration, including its qualified filters and candidate observations.
It does not mean every candidate succeeded. Neither empty diagnostics nor native list exhaustion proves full native coverage, compatibility, history validity, or resume safety.

`SessionDiscoveryDiagnostic` reports `file-inspection-failed` only after an actual supported inspection of an admitted file fails before session identity or classification is established.
A listing omission or unattempted candidate cannot produce this diagnostic. The diagnostic establishes no corrupt, inaccessible, incompatible, account, format, or busy classification.
It does not increment `skipped.corrupt` or `skipped.inaccessible`. Consumers can display a fixed message from `kind`.
Its subject is `{ kind: 'discovery-file', token: string }`, structurally distinct from `SessionReference`.
The adapter generates an opaque token independent of paths, filenames, native IDs, account names, format names, error messages, and their encodings or hashes.
The token is unique among file subjects within one call and stable for that subject until the call settles. Distinct admitted paths stay distinct, including hardlinks or files sharing a native session ID.
Tokens have no cross-call identity guarantee. Hosts correlate retained pages with their own call identity.
The adapter releases any temporary token-to-file association at settlement. No public resolver, persistent map, or process-global cache exists.
The returned subject is display and correlation data. It grants no reopen, retry, inspect, or resume access.

The adapter owns authorization, wire validation, classification evidence, exact-field construction, and redaction before returning diagnostics.
It must not spread raw RPC records or copy a qualifier's relative-path token. No arbitrary native message field crosses this contract.
Core types cannot prove token provenance, sanitize strings, reject aliased extra fields, or freeze runtime records. Readonly is a compile-time promise.
`serializeDiagnostic` retains its existing provenance rules and redacts these unowned records.
Each examined candidate contributes at most one diagnostic, so `diagnostics.length <= examined <= bounds.maxExamined`.
The adapter enforces nonblank control-free tokens within `sessionLimits.identifierLength`, result limits, time limits, and abort together.
It retains all settled sessions, examined and skipped counts, and diagnostics through completion, every named truncation, cancellation, and fatal failure. It never prunes earlier diagnostics to fit a later stop.
A settled failed inspection is recorded before a later abort or budget check. Cancellation alone creates no failed-file diagnostic.
These partial pages remain successful outer outcomes. Outer `native-failure`, `cancelled`, or `bounds-exceeded` errors cannot discard their observations.
Admission failures before useful discovery retain the existing outer errors, including scope-wide `inaccessible` failures.
A fatal discovery failure returns a retained `failed` page with required `sessions`, `examined`, `skipped`, and `diagnostics` fields.
Its fixed `code` is `inaccessible` only for an established access failure. Generic native, process, or transport failure uses `native-failure`.
Neither code carries native error objects, prose, paths, native IDs, or account data. A fatal failure alone establishes no corrupt or inaccessible file count.
An empty failed page is valid when no observation settled. It requires no fabricated session, diagnostic, or positive count.
The adapter records a settled fatal condition before considering a later abort. That later abort cannot replace the failed ending.
If abort settles while a native operation remains unresolved, cancellation can settle first. Its later failure creates no failed-file diagnostic by itself.
Adapters own event arbitration, outstanding operations, and cleanup. Cleanup failure after useful work also retains observations in a failed page, never an outer error.
A cleanup failure does not establish that every owned resource terminated. Additional byte or depth termination reasons require separate scope.

Inspection reports available, absent, busy, or incompatible. Inspection cancellation or exhausted budgets return `cancelled` or `bounds-exceeded` errors.
Neither discovery nor inspection acquires a lease. A later resume operation rechecks native availability before use.
The installed session tests verify envelope validation, budget validation, typed outcomes, retained observations, and diagnostic separation from session handles.
The installed controlled consumer accumulates observations, handles a rejected operation, and checks both fatal-before-abort and abort-before-failure settlement orders.
These checks prove that consumer's representation and handling. Core supplies no production discovery accumulator or native event arbitration.
Native fatal process and transport faults, cleanup failure, access-denied classification, resource release, and adapter budget enforcement still need adapter runtime qualification.
Native discovery and resume remain adapter qualification obligations.

## Private Codex transport

`openCodexTransport` borrows one channel registration and detaches it once. The host owns channel and native-process shutdown.
`detach` can run synchronously inside channel callbacks or an active, unsettled `write`.
Requests, notifications, and required server replies share one bounded FIFO and one active writer. A scheduled pump leaves reader delivery before writing.
The shared wire reader owns frame and chunk byte bounds. No second input queue exists. Adapter handlers and observers enter outside reader delivery.
Handler entry and correlated reply delivery can precede queued observations. Adapters correlate native identifiers independently of observation order.
Client waits and server ID leases have separate bounds. Server IDs remain leased until their required reply write actually settles.
Caller signals own wait deadlines. Queued cancellation means `not-sent`; cancellation after write entry means `uncertain`.
`written` proves local write settlement. A correlated `reply` preserves native data but proves neither native acceptance nor safe replay.
Handler, observer, and writer deadlines close local transport ownership. Noncooperative actual operations remain leased until they settle.
Request callbacks awaiting human decisions retain their lease. `handlerTimeoutMs` therefore bounds approval latency for the whole session.
The first terminal reason, diagnostic tail, detach failure, and unsettled-operation snapshot form one stable close report.
The report also counts parsed observations that never entered the observer and scheduled requests that never entered their callback, including the overflow-triggering observation.
Bytes after the first terminal are ignored and excluded from discard counts. Host channels forward remaining stdout and stderr before signalling `process-exit` or `eof`.
Close shuts the reader before abort signals or detach can reenter. Pending waits settle promptly without waiting for borrowed operations to stop.
Caller output overflow refuses that caller. Each server lease reserves one reply slot. Observation overflow closes with explicit discard counts.
Frame bytes, chunk bytes, diagnostic tail bytes, pending calls, server leases, writes, observations, and three callback deadlines are explicit bounds.
Retained serialized bytes are bounded by one reader frame, the caller and reply output slots, and the diagnostic tail.
Observation slots bound parsed objects whose source frames obey the frame bound. Parsed objects have separate heap costs.
Trusted outgoing serialization and consumer-retained data are outside those memory bounds. Timers cannot preempt synchronous JavaScript.
Raw envelopes and diagnostic bytes stay private. The adapter owns method decoding, unsupported replies, admitted extensions, and redaction. Trusted request callbacks can return `RpcReply.error` without closing the session; an actual throw or rejection closes with `handler-error` and sends no reply.
This private component does not spawn native processes, qualify routes, infer approvals, retry work, or establish complete adapter readiness.

## Private Codex sessions

`src/adapters/codex/sessions.ts` is private (no package export) and borrows an initialized transport's `request` plus the host's `initialize` result, whose `codexHome` must equal the scope `home`, which must be a canonical absolute path.
It implements core `SessionDiscovery` and `SessionInspection` with core codes only, adds `bind` and `prepareResume`, and sends only `codexSessionMethods`: `config/read`, `account/read`, `getConversationSummary` and metadata-only `thread/read`.
The binding is `codex`, `0.169.0`, the requester, the home path as `authorizedScope`, and `codex-thread/paginated` or `codex-thread/legacy` from `Thread.historyMode`.
In direct mode (no `route` on the scope) the requester is the native login, `chatgpt:<userId>` or `apiKey`; a null account is `inaccessible`.
With a host-selected LiteLLM proxy route (`CodexProxyRoute` in `route.ts`, also an `openCodexExecution` option), provider command auth leaves native with no login, so the requester is the route principal `litellm-proxy:sha256:<hex>`, a SHA-256 over the native provider id, the canonical proxy endpoint, credential purpose and the host auth scope's `engine` and `account`. The endpoint must be a canonical WHATWG href (`new URL(endpoint).href === endpoint`: http or https, no credentials, query or fragment, lowercase scheme and host, no default port, no dot segments) whose path ends exactly in `/v1`, and the host must generate the native `base_url` verbatim from that same string, since `config/read` echoes `base_url` unnormalized and is compared byte for byte. It is admitted only while `config/read` reports the route's `model_provider` with a `model_providers` entry whose `base_url` is exactly the route endpoint, `wire_api` is `responses`, `auth.command` is set, `requires_openai_auth` is false and no `env_key` or `experimental_bearer_token` is set (so a built-in provider, absent from `model_providers`, never binds), while `config.features` reports both `multi_agent` and `multi_agent_v2` as `false`, as `codexProxyConfig` pins them (native omits an unset feature, so a host that did not pass the generated args never binds a route a sub-agent's `spawn_agent` `model` could bypass), and `account/read` reports a null account with `requiresOpenaiAuth: false`; a native login under a route is `inaccessible`, never a fallback. A changed endpoint, provider or host scope is a different principal. The route principal is a host assertion: Switchboard does not verify the proxy's identity, as with `ProxyCredential`.
Both modes also take the effective provider from `config/read`: `model_provider` when it is a string, else Codex's default `openai` when it is absent or null; any other value is `native-failure`. Native resumes and runs a thread on its own `Thread.modelProvider` with that provider's credentials whatever the app-server's default, so a direct app-server whose config still lists a routed provider would otherwise resume a routed thread on the proxy under an `apiKey` binding (observed natively). Discovery therefore lists only threads whose `thread/read` `modelProvider` equals the effective provider, `inspect` and `prepareResume` refuse any other or missing provider as `inaccessible`, and `prepareResume`'s `ready` carries the provider.
Under a route, execution refuses `modelProvider` and any `config` on `thread/start` and `thread/resume` as `invalid-input`, unsent, because native lets either move a thread to another provider or endpoint; `turn/start` has neither field. In both modes a start or resume reply whose `thread.modelProvider` is not the requester's effective provider, or is missing, is `native-failure`: a start holds no reservation and a resume keeps it as for `identity-mismatch`. An invalid route at `openCodexExecution` is `invalid-input` with a `message` naming the failing rule.
Isolation holds at the reference level: the `litellm-proxy:` prefix keeps routed and direct principals disjoint, so a reference never resolves across modes, and the provider check keeps a direct requester off routed threads and a routed requester off direct ones. The writer registry intentionally keys by the complete `SessionReference` (x9av), so a routed and a direct reference to the same thread ID are different leases: a host must run one mode per Codex home.
Every operation refuses with `invalid-input`, before any history read, unless native `config/read` reports absolute `sqlite_home` and `log_dir` outside the home; an invalid route is `invalid-input` before any native request. A changed or unbindable requester is `inaccessible`, or `binding-mismatch` at resume. Every API key is the one principal `apiKey`, so a change between API keys is unqualified.
Discovery admits the `<home>/sessions` tree on the host first, inventories it with `discoverFiles` without opening a file, then asks native for each path's summary and metadata in code-unit path order, so a complete inventory does not depend on directory order. Failed files are path-free `file-inspection-failed` diagnostics; `skipped.corrupt` stays 0.
Known-target reads map only `thread not loaded: <id>` to `absent`, a loaded thread in this app-server process to `busy`, and a format mismatch to `incompatible{native-format}`. Other native errors are `native-failure`.
`prepareResume` rereads everything on each call and returns `ready{threadId, provider}` only for paginated history. It reserves no writer and dispatches nothing; the execution owner reserves first, resumes with the exact ID and rejects a different returned `thread.id` or `thread.modelProvider`.
Busy writers in other processes, creator-account attribution, permission-denied files and archived history are not classified. The host owns the process, the private index, credentials and a stable home namespace.

## Private Codex execution

`src/adapters/codex/execution.ts` is private (no package export). The host owns the app-server process: executable, environment, native configuration, credentials and termination. The module opens the transport over a host-lent channel, sends the host's `initialize` params unchanged and requires the reply's `codexHome` to equal `home`. Aborting the startup signal mid-handshake closes the transport and reserves nothing.
The transport observer is synchronous and never awaits a consumer. Notifications route by thread and turn ID, never by order, into per-session bounded event streams; notifications no session claims and unmatched replies go to the execution stream and are counted. Usage keeps native `total` and `last` field by field, labelled per method (`qualified` by native proof X1 on linux/arm64 and x64), and is never summed or treated as per-request usage.
Writers are reserved in a process-local registry keyed by the complete validated `SessionReference` (binding and opaque ID), not by policy, binding or token. Resume reserves before pg51 `prepareResume`, sends `thread/resume` with the exact ID and rejects a different returned ID as `identity-mismatch`. A second open of a held reference is `busy` before any native request; independent sessions proceed. Release is compare-and-release, so a late release from an earlier generation cannot free a replacement.
A reservation is released only on host-attested exit of the app-server holding it (the required `processExit`, or the channel ending with `process-exit` before `close()` detaches it). A turn terminal ends the turn, not the writer: natively the thread stays loaded after `thread/unsubscribe`, and a resume on another app-server fails while the holder lives (native proof X4, X5). Cleanup start or completion, rejection, transport loss other than `process-exit`, the cleanup deadline and an unrejected `thread/resume` never release. A closed session still counts toward `maxSessions` until its transport ends.
Each turn is one core dispatch operation and one `turn/start`, never resent. The caller's signal can prevent entry but never abandons a written `turn/start`; only `acknowledgementTimeoutMs` bounds it, and expiry is `outcome-unknown` with the writer retained. A transport `not-sent` is still `outcome-unknown` in core but is reported to the host as proven unsent. Reconciliation is `unsupported`. One turn per session at a time, because a second native `turn/start` may steer.
Server requests go only to the required host `onServerRequest` hook; the module answers none. `CodexSession.interrupt()` cancels without closing: at most one native `turn/interrupt` per turn, shared with `close`, reported as a request only (the turn's `completion` is the terminal); it never closes the session, releases the writer or resends, and a turn without a native ID within `cleanupTimeoutMs` is `not-needed`. Observer detach is not cancellation. Cross-process and durable admission, application cache and idle policy, and route policy compatibility remain host responsibilities. Evidence: [Codex execution qualification](../qualification/codex-execution.md).

## Private Codex interaction

`src/adapters/codex/interaction.ts` is private (no package export). Its `onServerRequest` is the host's execution hook; `attach(session)` binds each thread before its first turn with one observer lease. Command-execution and file-change approvals become core `PendingApproval` records whose `nativeApprovalId` is the JSON of the native request ID (type kept), turn, item and `approvalId`, and whose choices are exactly the request's own `availableDecisions` (a single-key object decision is an opaque choice written back verbatim; a command approval without the list is refused malformed; file changes without it use the bindings' four decisions). A choice the request did not offer is `choice-mismatch` with nothing written. `item/tool/call` and `item/tool/requestUserInput` are `-32601` when the host did not enable them and held when it did. Every other or unknown method is reported and answered `-32601`; malformed approvals `-32602`; unattached threads `-32601`. None is a permit, and the bridge never sends a policy, sandbox or decision of its own; a host that owns a refused method composes its hook in front.
`reply` validates with `parseInteractionContinuation` against the stored record, looks up by native identity only, runs the host's `recordIntent` before the single native write and then writes the bridge's own mapped decision once. Duplicates are `duplicate-interaction`, unknown, withdrawn, expired, lost or evicted targets `stale-interaction`; nothing is resent. Delivery stays `unknown`; only a declined command item is qualified no-effect evidence. A native terminal, `serverRequest/resolved` or item completion withdraws a live approval with a decision-free `-32000`; transport loss settles it `lost` with nothing written and the transport end reason as `cause`.
A held approval keeps its transport handler lease while other traffic flows. `maxPending < maxHandlers` is required, and approvals beyond `maxPending` are refused with `-32000` while a slot remains; a burst above `maxHandlers` still ends the transport, so size `maxHandlers > maxPending` with headroom for the refusals in one read. `handlerTimeoutMs` bounds approval latency for the whole transport unless the host selects `expiry.afterMs` below it, which answers a decision-free `-32000` and settles `expired`. Declared `item/tool/call` and host-enabled `item/tool/requestUserInput` are held as tool continuations. With neither option set, both stay `-32601`, and delegation stays unsupported. Evidence: [Codex interaction qualification](../qualification/codex-interaction.md).

## Event delivery

`createEventStream<T>` returns an `EventStream<T>` with `publish`, `subscribe`, and `close`.
`EventObserver<T>` exposes only `subscribe`. This type is a compile-time API restriction, not an authorization boundary.
Adapters define event payloads and preserve native features and reported usage. Core supplies no universal event vocabulary or manufactured reasoning.
Payloads are borrowed references. Core neither clones nor freezes them, and the host owns payload immutability and byte limits.

`EventStreamBounds` requires positive safe integers for `maxObservers`, `capacity`, and their product. Invalid bounds throw `RangeError`.
Each observer receives events in FIFO order through an asynchronous drain, with at most one active callback.
`publish` never awaits a listener. Its result reports how many observers accepted the event and how many disconnected on overflow.
`capacity` counts queued events plus the active callback. Overflow disconnects that observer, clears its queue, and ends its subscription with `overflow`.
Other observers continue independently. The helper stores no replay history. The host owns durable replay.

`maxObservers` counts observer leases, including retired observers whose scheduled drain or active callback has not settled.
Disposal cannot repeatedly free admission while callbacks remain hung. Admission recovers when those callbacks settle.
`subscribe` returns a `capacity` error when all leases are occupied, or a `closed` error after stream closure.
An already-aborted signal returns an immediately ended `aborted` subscription without consuming a lease, unless the stream is closed.

Disposal, input abort, overflow, listener failure, and close settle `Subscription.ended` once with the corresponding terminal reason.
They detach the input abort handler, clear queued references, abort the callback's delivery signal, and prevent later delivery.
`ended` means detached. An arbitrary consumer callback may still run, and a late rejection is consumed.
Listener throws and rejections end only that subscription with `listener-error`. Repeated disposal and close have no further effect.
`publish` returns `closed` after closure. Delivery cancellation never cancels native work, and the helper accepts no native cancellation callback.
Installed-consumer tests verify these delivery guarantees. Native event mapping and native-operation cancellation require separate adapter qualification.

## Scoped authentication

`createAuthContext` snapshots a host-authorized engine, account, adapter instance, session, and route.
Direct and LiteLLM configurations remain distinct. Proxy configuration requires its endpoint, protocol, and proxy credential purpose.
The host authorizes endpoints, including private HTTP proxies. URL checks establish syntax only.
Adapters validate protocol, native options, direct credential material, and any conflicting authentication headers against their native family.
Opaque native options and direct material retain their identity and are not deep-frozen.
Known scope, route, headers, boundary, and proxy credential fields are copied and frozen.

Adapters call `resolve` at each supported invocation or request boundary, including resumed work.
Each call supplies a fresh frozen context and the caller's abort signal to the host resolver.
The helper does not cache, coalesce, retry, choose fallback routes, or dispatch native requests.
Cancellation is cooperative during resolution and checked before and after it.
Safe failure messages exclude raw resolver errors and credentials. A proxy purpose label is a host assertion, not issuer verification.
Installed fixtures verify scope isolation, credential rotation, cancellation, route preservation, and redacted failures.
Native boundary wiring and direct/LiteLLM qualification remain adapter obligations.

## Native interactions and continuations

Approval, tool, and delegation targets carry exact native identifiers and a bound `SessionReference`.
Host correlation IDs do not replace native identifiers. Approvals can exist without a tool call.
`PendingApproval` advertises bounded native choice IDs with their labels, native policy, and request payloads.
The host policy selects an advertised choice or withholds locally. There is no default policy or universal permit/deny translation.
A thrown policy leaves the request pending. Withholding is not a dispatch continuation.
Finite advertised choices form this capability's boundary. Adapters must preserve parameterized native permissions through an evidence-backed extension when needed.

Tool result, native delivery confirmation, and tool effects are separate facts. Failure or cancellation does not prove that no effect occurred.
Unknown delivery or effects never authorize retries. Delegated work distinguishes completed, cancelled, and unknown outcomes.
`parseInteractionContinuation` validates both the supplied expected interaction and the continuation envelope.
It matches every binding field, session token, target kind, applicable native ID, tool presence, and advertised choice.
Delegations require the exact child target set regardless of order, without duplicates or missing or extra children.
Choice and delegation lists must be nonempty and at most 1000 entries, exposed by `interactionLimits`.
Known envelopes are copied and frozen. Native extension labels require bounded namespaces and positive safe integer schema versions.
Opaque `data` remains unknown and retains its identity; this promises neither deep immutability, serialization, nor native semantic validation.
Input-access exceptions return a safe `invalid-input` error without the raw exception.
Successful parsing proves correspondence to the supplied expected record. Native pending state and single-use consumption live in the adapter that owns the pending record (Codex: [Private Codex interaction](#private-codex-interaction)); persistence and reconciliation remain host work.
Installed fixtures verify correspondence, fact combinations, mutation isolation, malformed inputs, and public type discrimination.
Restoring a pending frontend batch after process loss is an application choice. The repository ADR `docs/architecture/frontend-restore.md` describes the contract.

## Scoped filesystem discovery

`discoverFiles<T>` enumerates one explicit host-authorized root per call and validates its exact account/scope binding before I/O.
`namespace: 'host-stable'` asserts that the host controls stable path resolution throughout the call, including ancestors and mount topology.
Portable Node path APIs cannot prove confinement against hostile concurrent ancestor swaps. Rechecks do not establish that security property.
The root is canonicalized once, allowing aliases such as macOS `/tmp`. Descendant symlinks and nonregular leaves are rejected.
Files use no-follow, nonblocking opens, bigint device/inode checks, and reads from the same verified handle.
Relative names describe entries; they are not reopenable path leases. Hardlink provenance is not established.

`FileDiscoveryBounds` adds depth, per-file bytes, and total bytes to the session discovery budgets.
`fileDiscoveryLimits` exposes ceilings of depth 64, 16 MiB per file, and 64 MiB total bytes, alongside session limits.
Enumeration is iterative depth-first with bounded directory buffering. Every returned entry counts before filtering.
Root depth is zero. Skipped descent marks depth truncation. Exact budget exhaustion reports truncation without unbudgeted EOF probes.
Actual read bytes include an oversize sentinel. Incomplete or oversized contents are not decoded.
Pages distinguish completion, cancellation, and named truncation, with examined/read counts and corrupt, inaccessible, absent, rejected, and oversized skips.
Errors expose fixed codes without OS text, absolute candidate paths, or contents. Configuration access is captured once before validation.

The adapter supplies trusted synchronous bounded selection and decoding callbacks. Their allocation and returned values are outside the byte-read budget.
Adapters validate decoded native session references against the authorized binding before publishing them.
Cancellation and deadlines are cooperative; outstanding I/O settles before handle cleanup. Content can change during reads.
The helper does not write, lock, migrate, or dispatch native history. Reads can update access metadata.
Real temporary filesystem fixtures verify traversal, symlinks, permissions, budgets, replacement, cancellation, and cleanup.
These tests do not qualify native formats or prove confinement when the host's namespace-stability precondition is false.

## Safe diagnostics

`createSafeError` lets trusted adapters assert one of the qualified adapter or authentication error codes.
Each code has a fixed message. It accepts no raw message or metadata, and malformed runtime codes become `native-failure`.
`normalizeError` preserves only exact error objects created by this module instance, using private identity tracking.
Clones, structural lookalikes, proxies, foreign package instances, and arbitrary native errors become the fixed native failure.
It never reads properties, prototypes, getters, keys, or coercion hooks on raw values.

`summarizeDiagnostic` wraps an owned error or suppresses an endpoint, headers, credentials, checkpoint, or native payload in full.
Invalid runtime categories become a native-data redaction. Returned records and nested errors are frozen.
`serializeDiagnostic` emits precomputed JSON only for owned records; all other inputs produce the fixed native-data redaction.
Every supported projection is at most 512 UTF-8 bytes with fixed depth and vocabulary.
These helpers do not sanitize arbitrary host events or establish whether an adapter's asserted condition is true.
Adapters must qualify native error mappings separately. No existing module's error is automatically trusted by structural similarity.
## Single-attempt dispatch

`createDispatchOperation` captures an immutable host operation identity and either an existing session reference or a new-session binding.
The host supplies `recordIntent` and a native dispatch closure. Before intent resolves, the host must durably record the exact command and acquire admission.
The helper does not store that command, persist receipts, or enforce uniqueness across handles or processes.
`run()` reserves and returns the same promise before any callback or lifecycle publication. One handle enters native dispatch at most once.
The original result and promise remain stable for the lifetime of the handle.

An abort before native entry or an intent failure returns `not-dispatched`. The signal is checked after lifecycle publication immediately before entry.
After entry, throws, rejections, malformed observations, and mismatched evidence become `outcome-unknown`, including cancellation errors.
Cancellation cannot establish rollback or nonacceptance. No retry, timeout, or polling is provided.
Callbacks are cooperative; awaiting this handle's own `run()` inside a callback creates a dependency cycle.

Native observations distinguish unknown, accepted, and conclusive results. Conclusive results retain the adapter's exact result, including rejection or pending interaction.
Evidence carries the exact host identity, a native acknowledgement source, a separately named native operation reference or null, and a native extension.
Known envelopes are copied and frozen; opaque native data and generic results retain their original identity.
Validation establishes correspondence with the requested identity, not the native authority of an adapter's assertion.
Malformed construction, including proxy signals, exposes a fixed `TypeError` without raw error data and executes no callbacks.
If a retained signal later becomes unreadable, the cached `run()` promise rejects with `TypeError('Invalid dispatch signal.')` before native entry.
It emits no fabricated terminal observation. The supported Node getter does not prove an unforgeable signal brand; the helper inspects no private signal state.

Borrowed lifecycle publication contains only a phase. Publisher failures, closed streams, overflow, and observer failures cannot change native execution or its result.
The host remains responsible for durable outcome storage and exclusion among duplicate identities.
Both fresh and recovery handles expose explicit `reconcile(signal)`. Recovery mode has no `run()`, native dispatch callback, or intent callback.
It can restore a prior native observation or start with identity-only uncertainty. The host supplies authorized durable context and any trusted prior receipt.
Fresh reconciliation returns `not-ready` until the run snapshot exists and never starts execution. If run rejects from signal invalidation, no snapshot exists and reconciliation remains not-ready.

One outstanding lookup promise coalesces concurrent and reentrant calls. The first signal owns that lookup; later signals are ignored.
Lookups require the exact operation identity and an `authoritative-native-lookup` source for positive observations.
Unknown, failed, malformed, aborted, or conflicting lookups preserve prior knowledge. An absent record cannot establish nonacceptance or safe retry.
A known native operation reference survives a null lookup reference, and a conflicting nonnull reference is rejected.
Conclusive observations latch permanently; restored conclusive and fresh not-dispatched observations require no lookup.
The original fresh run promise and snapshot never change as reconciliation refines the separate current snapshot.
An invalid lookup signal rejects with a fixed `TypeError`; cancellation cannot invalidate already returned positive native evidence.
The helper checks correspondence, not native authority. It never dispatches during recovery, retries a command, or persists an outcome.

## Native prerequisites and checked evidence

Node 24.22.3 with npm 11.19.1 is the selected foundation toolchain.
TypeScript 7.0.2 compiles the core with strict NodeNext settings, ES2022 libraries, and Node declarations.
The isolated Pi project uses ES2024 and `skipLibCheck: true` because Pi 1.5.2 declarations fail TS1543.
Root and installed consumer compilation retain `skipLibCheck: false`, and the package gate checks that Pi public declarations do not load SDK declarations.
TypeScript consumers need `@types/node` as a development dependency for public `AbortSignal` contracts.
The package and installed consumer checks use pinned `@types/node` 24.19.2 without DOM libraries.
The supported Node range stays within this selected major until other versions receive validation.
[Node's release index](https://nodejs.org/dist/index.json) supplied the selected runtime and bundled npm evidence checked on 2026-11-13.

The registry metadata below was checked on 2026-11-13 during foundation design.
These versions are research evidence, not installed dependencies or live qualification results.

| Prospective dependency | Checked version | Declared Node prerequisite |
| --- | --- | --- |
| [Claude Agent SDK](https://registry.npmjs.org/@anthropic-ai/claude-agent-sdk/0.3.323) | 0.3.323 | `>=18.14.0` |
| [Codex SDK](https://registry.npmjs.org/@openai/codex-sdk/0.169.0) | 0.169.0 | `>=18` |
| [Codex CLI](https://registry.npmjs.org/@openai/codex/0.169.0) | 0.169.0 | `>=16` |
| [Pi coding agent](https://registry.npmjs.org/@earendil-works/pi-coding-agent/1.5.2) | 1.5.2 | `>=22.19.0` |
| [Pi agent core](https://registry.npmjs.org/@earendil-works/pi-agent-core/1.5.2) | 1.5.2 | `>=22.19.0` |
| [Pi AI](https://registry.npmjs.org/@earendil-works/pi-ai/1.5.2) | 1.5.2 | `>=22.19.0` |

The [Codex SDK documentation](https://developers.openai.com/codex/sdk/) specifies server-side Node 18 or later.
[Codex app-server](https://developers.openai.com/codex/app-server/) uses a native Codex process.
The checked Codex launcher and Claude SDK manifests include platform-specific optional runtime packages.
The current [Pi source repository](https://github.com/earendil-works/pi) is authoritative for the checked `@earendil-works` packages.
Native integration qualification must establish executable availability, supported authentication, and authorized session access on the target host.
Dependency engine declarations alone do not establish those facts.
Switchboard's MIT license does not establish the license terms of prospective native dependencies.

All three native integrations require separate direct and LiteLLM qualification.
Record exact native, proxy, model, protocol, and source versions with configuration that excludes secrets.
Distinguish deterministic fixture checks from live evidence.
All GitHub Actions must use Linux runners. Record macOS native evidence separately.
The temporary consumer check proves packaging on the machine running it. It does not qualify a native integration on either platform.

## Basic AG-UI projection

Hosts serialize `accept` calls and publish each successful batch in order. Local validation failures emit nothing and fault the actor.
Success and cancellation require every opened stream or step to close. Only observed native failure abandons open entities.
Ended tool arguments can remain unanswered; an optional success `pendingTools` list must match first-start order exactly.
`NativeRef` IDs use the public JSON tuple `[1, sourceKey, kind, scope, id]`. Message references share one identity domain across text and tool results.
The tuple preserves lone UTF-16 surrogates and omits host run IDs so stable native references survive resume.
These identifiers are reversible public values. The host must supply authorized public namespaces and IDs.
Adapters supply resolved ownership on every entity fact. Omission means root ownership, including text and tool continuations.
When native continuations omit attribution, the adapter carries forward the opener owner before calling `accept`.
Identical closed text/tool streams may reopen. Owner or opener disagreement faults the actor.
Step identity becomes `stepName`; an observed display label is retained in `metadata.switchboard.name`.
Returned events and nested JSON are detached and recursively readonly. No native availability or qualification follows from representation fixtures.

## AG-UI values and explicit public data

State snapshots and deltas preserve bounded JSON and all six JSON Patch operations, including extra operation members.
The mapper forwards patches without applying them or retaining materialized state. Native producers remain responsible for patch applicability.
Activity snapshots establish a message baseline. Replacing snapshots can re-mint ownership and type; `replace: false` retains the established values.
Activity deltas require that baseline and matching resolved ownership, and can change the activity type.
Raw and custom facts require nonempty namespace and version strings plus selected `publicPayload`. No raw native error or private payload is selected automatically.
JSON validation establishes shape and budgets; it cannot establish that selected values are safe to publish.
A valid `not-observable` fact emits an empty batch without fabricating a native event. The host records the gap independently.
`describeProjection` reports represented families separately from caller-asserted native availability and qualification.
Missing assertions remain undeclared. Mapping or fixture success never upgrades native availability or qualification.

## AG-UI reasoning

Reasoning spans and messages have independent lifecycles in the single bounded actor ledger. No hidden reasoning or subagent lifecycle is synthesized.
Opaque encrypted observations open and close nothing. Their attribution records the producer independently of target ownership.
Unknown target identities consume capacity without establishing target existence. Later actual openers establish their own ownership.
The host supplies authorized reasoning facts and owns publication, persistence and native qualification. All six native routes remain unqualified.
